package com.example.laundrysepatu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView : ListView = findViewById(R.id.lv_list)
        val adapter = HeroAdapter()
        listView.adapter = adapter

        val dataName = resources.getStringArray(R.array.data_jenis)
        val dataDesc = resources.getStringArray(R.array.data_desc)
        val dataPhoto = resources.obtainTypedArray(R.array.data_foto)
        dataPhoto.recycle()

        val heroes = arrayListOf<Hero>()
        for (position in dataName.indices){
            val hero = Hero(
                dataPhoto.getResourceId(position, -1),
                dataName[position],
                dataDesc[position]
            )
            heroes.add(hero)
        }
        adapter.heroes = heroes
    }

}