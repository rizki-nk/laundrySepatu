package com.example.laundrysepatu


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import de.hdodenhof.circleimageview.CircleImageView

class HeroAdapter : BaseAdapter() {
    internal var heroes = arrayListOf<Hero>()

    override fun getCount(): Int = heroes.size

    override fun getItem(i: Int): Any = heroes[i]

    override fun getItemId(i: Int): Long = i.toLong()

    override fun getView(position: Int, view: View?, viewGroup: ViewGroup): View {
        val itemView = view ?: LayoutInflater.from(viewGroup.context).inflate(R.layout.item_hero, viewGroup, true)
        val viewHolder = ViewHolder(itemView)

        viewHolder.bind(heroes[position])
        return itemView
    }

    private inner class ViewHolder constructor(itemView: View){
        private val txtName : TextView = itemView.findViewById(R.id.txt_name)
        private val txtDesc : TextView = itemView.findViewById(R.id.txt_desc)
        private val imgPhoto : CircleImageView = itemView.findViewById(R.id.img_photo)

        fun bind(hero: Hero){
            txtName.text = hero.name
            txtDesc.text = hero.desc
            imgPhoto.setImageResource(hero.photo)
        }
    }

}